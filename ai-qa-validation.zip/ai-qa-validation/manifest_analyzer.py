import json
from keyword_extractor import extract_keywords
from capability_rules import capability_rules
from mismatch_detector import detect_findings
from guideline_validator import validate_guidelines
from suggestion_engine import generate_suggestions


def analyze_manifest(file):

    manifest = json.load(file)

    # handle different manifest formats
    name = manifest.get("app_name") or manifest.get("name") or "Unknown"

    developer = manifest.get("developer") or manifest.get("publisher") or "Unknown"

    description = manifest.get("description", "")

    capabilities = manifest.get("capabilities", [])

    scopes = manifest.get("scopes", {})
    if not isinstance(scopes, dict):
        scopes = {}

    # Extract keywords
    keywords = extract_keywords(description)

    # Generate QA suggestions
    suggestions = generate_suggestions(manifest, capabilities)

    for cap in capabilities:

        if cap in capability_rules:

            suggestions.extend(capability_rules[cap])

    findings = detect_findings(manifest, description, capabilities)
    guideline_findings = validate_guidelines(manifest)
    all_findings = findings + guideline_findings

    return {
    "name": name,
    "developer": developer,
    "description": description,
    "capabilities": capabilities,
    "scopes": scopes,
    "keywords": keywords,
    "suggestions": suggestions,
    "findings": all_findings
}