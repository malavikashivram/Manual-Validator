


def extract_keywords(description):

    # Lazy load heavy dependencies to speed up app startup
    from rake_nltk import Rake
    from sklearn.feature_extraction.text import TfidfVectorizer

    # --- Primary keyword extraction using RAKE ---
    rake = Rake()

    rake.extract_keywords_from_text(description)

    keywords = rake.get_ranked_phrases()

    # Limit number of keywords
    keywords = keywords[:6]

    # --- Fallback to TF-IDF if RAKE returns nothing ---
    if not keywords:

        try:
            vectorizer = TfidfVectorizer(stop_words="english", max_features=6)
            tfidf_matrix = vectorizer.fit_transform([description])
            keywords = vectorizer.get_feature_names_out()
            keywords = list(keywords)
        except ValueError:
            keywords = []

    return keywords


def detect_mismatch(description, capabilities):

    mismatches = []

    description = description.lower()

    # Dashboard / analytics validation
    if "dashboard" in description or "analytics" in description:

        if "configurable_tab" not in capabilities and "static_tab" not in capabilities:

            mismatches.append(
                "Description references dashboards or analytics but no tab capability exists."
            )

    # Bot validation
    if "bot" in description or "chatbot" in description:

        if "bot" not in capabilities:

            mismatches.append(
                "Description mentions bot functionality but bot capability is not defined."
            )

    # Search validation
    if "search" in description:

        if "message_extension" not in capabilities:

            mismatches.append(
                "Description references search functionality but message extension capability is missing."
            )

    return mismatches