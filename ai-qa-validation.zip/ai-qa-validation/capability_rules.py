capability_rules = {

    "bot": [
        "Verify bot responds to user queries",
        "Validate conversational flow",
        "Check bot authentication",
        "Verify bot works across all declared scopes"
    ],

    "static_tab": [
        "Verify static tab loads correctly",
        "Validate UI components inside the tab",
        "Ensure tab displays expected content"
    ],

    "configurable_tab": [
        "Verify tab configuration settings",
        "Validate configuration save functionality",
        "Ensure dashboard loads inside tab"
    ],

    "message_extension": [
        "Validate search functionality",
        "Verify message insertion into group chat or channel",
        "Check command triggers"
    ],

    "meeting_extension": [
        "Verify meeting side panel loads correctly",
        "Validate meeting chat interactions",
        "Check real-time meeting insights"
    ],

    "copilot": [
        "Validate AI agent response generation",
        "Verify Copilot retrieves relevant organizational data",
        "Check AI generated recommendations"
    ]
}