def validate_guidelines(manifest):

    findings = []

    capabilities = manifest.get("capabilities", [])
    scopes = manifest.get("scopes", {})
    if not isinstance(scopes, dict):
        scopes = {}

    # Configurable tab scope validation
    if "configurable_tab" in capabilities:

        tab_scopes = scopes.get("configurable_tab", [])

        if "personal" in tab_scopes:
            findings.append({
                "severity": "Warning",
                "message": "Configurable tabs should typically not use personal scope. Expected scopes are groupchat or channel."
            })

    # Bot validation
    if "bot" in capabilities:

        bot_section = manifest.get("bots")

        if not bot_section:
            findings.append({
                "severity": "Critical",
                "message": "Bot capability declared but bot configuration is missing."
            })

        else:
            bot = bot_section[0] if isinstance(bot_section, list) and len(bot_section) > 0 else (bot_section if isinstance(bot_section, dict) else {})
            commands = bot.get("commandLists")

            if not commands:
                findings.append({
                    "severity": "Warning",
                    "message": "Bot capability exists but no commands are defined in commandLists."
                })

    # Meeting extension validation
    if "meeting_extension" in capabilities:

        meeting_scopes = scopes.get("meeting_extension")

        if not meeting_scopes:
            findings.append({
                "severity": "Warning",
                "message": "Meeting extension capability exists but no meeting scopes are defined."
            })

    # Copilot validation
    if "copilot" in capabilities:

        if "agent_id" not in manifest:
            findings.append({
                "severity": "Warning",
                "message": "Copilot capability declared but agent_id is missing."
            })

    return findings