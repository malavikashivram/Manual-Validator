from flask import Flask, render_template, request
from manifest_analyzer import analyze_manifest

app = Flask(__name__)


@app.route("/", methods=["GET", "POST"])
def home():

    if request.method == "POST":

        file = request.files["manifest"]

        result = analyze_manifest(file)

        return render_template("result.html", result=result)

    return render_template("index.html")


if __name__ == "__main__":
    app.run(debug=True, host="localhost")