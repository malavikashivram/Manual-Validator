def detect_findings(manifest, description, capabilities):

    findings = []

    description = description.lower()

    app_name = manifest.get("app_name") or manifest.get("name")
    developer = manifest.get("developer") or manifest.get("publisher")

    scopes = manifest.get("scopes", {})
    if not isinstance(scopes, dict):
        scopes = {}

    bot_id = manifest.get("bot_id")
    agent_id = manifest.get("agent_id")

    # App name validation
    if not app_name:
        findings.append({
            "severity": "error",
            "message": "App name is missing in the manifest."
        })

    # Developer validation
    if not developer:
        findings.append({
            "severity": "warning",
            "message": "Developer or publisher field is missing."
        })

    # Check scopes for each capability
    for capability in capabilities:

        cap_scopes = scopes.get(capability)

        if not cap_scopes:
            findings.append({
                "severity": "error",
                "message": f"No scopes defined for capability: {capability.replace('_',' ').title()}."
            })

    # Invalid scope under configurable tab
    if "configurable_tab" in capabilities:

        tab_scopes = scopes.get("configurable_tab", [])

        if "personal" in tab_scopes:
            findings.append({
                "severity": "error",
                "message": "Invalid scope: Configurable tabs cannot use personal scope."
            })

    # Bot + Copilot validation
    if "bot" in capabilities and "copilot" in capabilities:

        if not bot_id or not agent_id:
            findings.append({
                "severity": "error",
                "message": "Bot ID or Agent ID missing while bot and copilot capabilities exist."
            })

        elif bot_id != agent_id:
            findings.append({
                "severity": "error",
                "message": "Bot ID and Agent ID must match when bot and copilot capabilities are present."
            })

    return findings