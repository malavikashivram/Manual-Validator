def generate_suggestions(manifest, capabilities):

    suggestions = []

    description = manifest.get("description", "").lower()
    scopes = manifest.get("scopes", {})
    if not isinstance(scopes, dict):
        scopes = {}

    # BOT suggestions
    if "bot" in capabilities:

        bot_scopes = scopes.get("bot", [])

        if "personal" in bot_scopes:
            suggestions.append(
                "Validate that the bot initiates conversations correctly in Personal scope."
            )

        if "groupchat" in bot_scopes:
            suggestions.append(
                "Verify the bot responds correctly within Group Chat conversations."
            )

        if "channel" in bot_scopes:
            suggestions.append(
                "Ensure the bot responds when mentioned inside Channel conversations."
            )

        if "question" in description or "help" in description:
            suggestions.append(
                "Validate that the bot answers user questions accurately based on the description."
            )

    # CONFIGURABLE TAB suggestions
    if "configurable_tab" in capabilities:

        tab_scopes = scopes.get("configurable_tab", [])

        if "channel" in tab_scopes:
            suggestions.append(
                "Verify that the configurable tab renders correctly inside Channel context."
            )

        if "groupchat" in tab_scopes:
            suggestions.append(
                "Validate that configuration settings persist when the tab is opened in Group Chat."
            )

        if "dashboard" in description or "analytics" in description:
            suggestions.append(
                "Verify the dashboard or analytics view referenced in the description loads correctly inside the tab."
            )

    # MESSAGE EXTENSION suggestions
    if "message_extension" in capabilities:

        suggestions.append(
            "Validate that message extension results can be inserted into chat conversations."
        )

        if "search" in description or "knowledge" in description:
            suggestions.append(
                "Verify the message extension returns relevant search results based on the description."
            )

    # MEETING EXTENSION suggestions
    if "meeting_extension" in capabilities:

        suggestions.append(
            "Verify meeting extension loads correctly in the meeting side panel."
        )

        if "summary" in description:
            suggestions.append(
                "Validate that meeting summaries referenced in the description are generated during the meeting."
            )

    # COPILOT suggestions
    if "copilot" in capabilities:

        suggestions.append(
            "Verify the Copilot agent responds to prompts and generates contextual responses."
        )

        if "report" in description or "analytics" in description:
            suggestions.append(
                "Validate that Copilot generates reports or insights mentioned in the application description."
            )

    return suggestions